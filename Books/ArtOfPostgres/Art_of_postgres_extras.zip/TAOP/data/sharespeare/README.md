# Shakespeare 2.00

  http://research.cs.wisc.edu/niagara/data/shakes/shaksper.htm
