execute foo('2010-02-01');
