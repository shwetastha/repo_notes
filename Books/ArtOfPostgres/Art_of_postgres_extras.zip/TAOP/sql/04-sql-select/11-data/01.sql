ALTER DATABASE f1db SET search_path TO f1db, public;
