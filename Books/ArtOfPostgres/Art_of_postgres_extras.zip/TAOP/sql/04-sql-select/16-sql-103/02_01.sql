 select count(*)
   from races;
