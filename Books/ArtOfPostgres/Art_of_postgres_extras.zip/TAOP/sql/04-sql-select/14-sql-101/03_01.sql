select code, driverref, forename, surname
  from drivers;
