select code,
       forename || ' ' || surname as fullname,
       forename,
       surname
 from drivers;
