select * from races fetch first 1 rows only;
