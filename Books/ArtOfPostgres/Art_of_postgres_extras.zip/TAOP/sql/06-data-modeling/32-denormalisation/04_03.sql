refresh materialized view cache.season_points;
