create index on geoname.geoname using gist(location);
