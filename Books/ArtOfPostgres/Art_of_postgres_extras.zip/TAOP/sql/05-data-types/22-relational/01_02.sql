select timestamp '0000-00-00 00:00:00';
