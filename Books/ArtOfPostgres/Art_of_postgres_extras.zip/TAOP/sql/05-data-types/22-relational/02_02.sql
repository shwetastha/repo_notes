select pg_typeof(driverid), pg_typeof(1) from drivers limit 1;
