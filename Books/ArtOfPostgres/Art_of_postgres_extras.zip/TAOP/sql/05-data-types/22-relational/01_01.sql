select date '2010-02-29';
