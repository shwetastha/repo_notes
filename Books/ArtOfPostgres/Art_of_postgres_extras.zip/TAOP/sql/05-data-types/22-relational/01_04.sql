select date 'today' + time 'allballs' as midnight;
