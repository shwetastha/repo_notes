\pset format wrapped
\pset columns 70
table opendata.archives_planete limit 1;
