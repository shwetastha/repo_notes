show client_encoding;
