   where grid = bigint '1' and position = bigint '1'
