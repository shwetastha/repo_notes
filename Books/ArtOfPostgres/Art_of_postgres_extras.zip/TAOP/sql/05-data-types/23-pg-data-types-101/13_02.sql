exclude using gist (currency with =, validity with &&)
