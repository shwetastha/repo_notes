CREATE TABLE tablename (
    colname SERIAL
);
