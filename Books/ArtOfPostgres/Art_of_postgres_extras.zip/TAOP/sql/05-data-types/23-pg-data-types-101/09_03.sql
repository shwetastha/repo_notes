select timestamptz '2017-01-08 04:05:06',
       timestamptz '2017-01-08 04:05:06+02';
