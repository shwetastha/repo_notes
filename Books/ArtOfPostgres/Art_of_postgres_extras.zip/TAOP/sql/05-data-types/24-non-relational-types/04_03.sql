alter table js alter column extra type jsonb;
