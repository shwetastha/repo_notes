create index on js using gin (extra jsonb_path_ops);
