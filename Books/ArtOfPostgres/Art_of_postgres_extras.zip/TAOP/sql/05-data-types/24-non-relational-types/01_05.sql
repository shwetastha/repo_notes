create index on hashtag using gin (hashtags);
