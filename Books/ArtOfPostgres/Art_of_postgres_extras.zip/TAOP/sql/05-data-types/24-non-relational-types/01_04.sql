select id, hashtags
  from hashtag
 limit 10;
