\pset format wrapped
\pset columns 70
table tweet limit 1;
