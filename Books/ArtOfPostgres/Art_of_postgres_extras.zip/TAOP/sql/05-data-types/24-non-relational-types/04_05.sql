select * from js where extra @> '[2,4]';
