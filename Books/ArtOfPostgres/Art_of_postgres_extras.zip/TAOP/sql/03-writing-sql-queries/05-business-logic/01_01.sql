  select name
    from track
   where albumid = 193
order by trackid;
