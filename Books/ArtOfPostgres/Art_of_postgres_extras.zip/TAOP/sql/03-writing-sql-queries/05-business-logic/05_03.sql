select * from get_all_albums(127);
