t1> insert into test(id) values(1);
t2> insert into test(id) values(1);
