select count(*) 
  from tweet.visitor;
