create index on lastfm.track using gist(title gist_trgm_ops);
