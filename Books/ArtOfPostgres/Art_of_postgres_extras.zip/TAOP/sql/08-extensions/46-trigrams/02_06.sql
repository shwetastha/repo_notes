select show_trgm('peace') as "peace", 
       show_trgm('Peace') as "Peace";
