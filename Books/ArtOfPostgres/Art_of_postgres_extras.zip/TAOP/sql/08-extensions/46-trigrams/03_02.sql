select artist, title
  from lastfm.track
where title %> 'peas';
