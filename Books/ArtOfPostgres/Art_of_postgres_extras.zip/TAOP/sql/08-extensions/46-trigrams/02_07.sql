select artist, title
  from lastfm.track
 where title %> 'peace';
