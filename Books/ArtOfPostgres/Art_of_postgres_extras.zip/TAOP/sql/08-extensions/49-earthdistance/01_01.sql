create extension cube;
create extension earthdistance;
