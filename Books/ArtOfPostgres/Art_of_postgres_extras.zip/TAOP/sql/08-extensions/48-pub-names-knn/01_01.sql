create table if not exists pubnames
 (
   id   bigint,
   pos  point,
   name text
 );
