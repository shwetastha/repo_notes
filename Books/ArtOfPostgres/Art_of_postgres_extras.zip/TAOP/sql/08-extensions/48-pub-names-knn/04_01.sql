create index on pubnames using gist(pos);
