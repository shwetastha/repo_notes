select   'f1 => a, f2 => x'::hstore
       - 'f1 => b, f2 => x'::hstore
       as diff;
