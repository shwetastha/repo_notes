select messageid, rts, favs
  from tweet.message_with_counters;
