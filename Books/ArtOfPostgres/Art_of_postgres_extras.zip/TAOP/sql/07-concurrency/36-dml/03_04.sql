  select uname, nickname, bio
    from tweet.users
order by userid;
