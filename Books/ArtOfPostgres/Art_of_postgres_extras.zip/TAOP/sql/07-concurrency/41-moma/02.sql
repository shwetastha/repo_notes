select name, bio, nationality, gender
  from moma.artist
 limit 6;
