insert into tweet.activity(messageid, action) values(:id, 'rt');
