    alter table tweet.activity
drop constraint activity_messageid_datetime_action_key;
